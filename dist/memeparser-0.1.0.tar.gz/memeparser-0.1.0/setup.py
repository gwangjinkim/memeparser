# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['memeparser']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.16,<2.0']

setup_kwargs = {
    'name': 'memeparser',
    'version': '0.1.0',
    'description': 'Parses MEME TF bindingsite files into an MemeParsed object',
    'long_description': None,
    'author': 'Gwang Jin Kim',
    'author_email': 'gwang.jin.kim.phd@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.5,<4.0',
}


setup(**setup_kwargs)
