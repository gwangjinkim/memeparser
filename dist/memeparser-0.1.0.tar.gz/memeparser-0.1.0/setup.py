# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['memeparser']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'memeparser',
    'version': '0.1.0',
    'description': 'Parses MEME TF bindingsite files into an MemeParsed object',
    'long_description': None,
    'author': 'Gwang Jin Kim',
    'author_email': 'gwang.jin.kim.phd@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.5,<4.0',
}


setup(**setup_kwargs)
